package com.huijiwanjia.app.wxapi;

public class WXEntryActivity extends EntryActivity {
}
