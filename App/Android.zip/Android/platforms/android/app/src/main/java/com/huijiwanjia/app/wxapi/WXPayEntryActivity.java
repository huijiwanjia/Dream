package com.huijiwanjia.app.wxapi;

public class WXPayEntryActivity extends EntryActivity {

}
