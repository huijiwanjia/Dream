package __PACKAGE_NAME__;

public class WXPayEntryActivity extends EntryActivity {

}
