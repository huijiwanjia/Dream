package __PACKAGE_NAME__;

public class WXEntryActivity extends EntryActivity {
}
